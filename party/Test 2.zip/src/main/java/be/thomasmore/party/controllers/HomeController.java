package be.thomasmore.party.controllers;

import be.thomasmore.party.model.Drink;
import be.thomasmore.party.model.Venue;
import be.thomasmore.party.repositories.DrinkRepository;
import be.thomasmore.party.repositories.PartyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {
    @Autowired
    private DrinkRepository drinkRepository;

    @GetMapping({"/", "/home"})
    public String home(Model model) {
        return "home";
    }

    @GetMapping("/about")
    public String about(Model model) {
        return "about";
    }

    @GetMapping("/drinklist")
    public String drinklist(Model model) {

        Iterable<Drink> drinks = drinkRepository.findAll();
        long nrOfDrinks = drinkRepository.count();
        model.addAttribute("drinks", drinks);
        model.addAttribute("nrOfDrinks", nrOfDrinks);
        model.addAttribute("showFilters", false);
        return "drinklist";
    }
}
