package be.thomasmore.party.repositories;

import be.thomasmore.party.model.Drink;

import be.thomasmore.party.model.Venue;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface DrinkRepository extends CrudRepository<Drink, Integer> {
    @Query("SELECT d FROM Drink d WHERE " +

            "(:maxPrice IS NULL OR d.price <= :maxPrice) AND " +
            "(:alcohol IS NULL OR d.alcoholic = :alcohol) AND " +
            "(:light IS NULL OR d.light=:light)  ")
    static List<Drink> findByFilter(
            @Param("maxPrice") Integer maxCapacity,
            @Param("alcohol") Boolean alcohol,
            @Param("light") Boolean light);
}
