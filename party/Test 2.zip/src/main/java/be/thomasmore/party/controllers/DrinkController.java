package be.thomasmore.party.controllers;

import be.thomasmore.party.model.Drink;
import be.thomasmore.party.model.Venue;
import be.thomasmore.party.repositories.DrinkRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;


@Controller
public class DrinkController {
    private Logger logger = LoggerFactory.getLogger(DrinkController.class);
    @Autowired
    private DrinkRepository drinkRepository;

    @GetMapping("/drinklist")
    public String drinklist(Model model) {

        Iterable<Drink> drinks = drinkRepository.findAll();
        long nrOfDrinks = drinkRepository.count();
        model.addAttribute("drinks", drinks);
        model.addAttribute("nrOfDrinks", nrOfDrinks);
        model.addAttribute("showFilters", false);
        return "drinklist";
    }
    @GetMapping({"/drinklist/filter"})
    public String drinkListWithFilter(Model model,

                                      @RequestParam(required = false) Integer maxPrice,
                                      @RequestParam(required = false) String alcohol,
                                      @RequestParam(required = false) String light
                                      ) {
        logger.info(String.format("drinkListWithFilter --  max=%d, alcohol=%s, light=%s",
                maxPrice, alcohol, light));

        List<Drink> drinks = DrinkRepository.findByFilter(maxPrice,
                filterStringToBoolean(alcohol), filterStringToBoolean(light));

        model.addAttribute("drinks", drinks);
        model.addAttribute("nrOfdrinks", drinks.size());
        model.addAttribute("showFilters", true);
        model.addAttribute("maxDistance", maxPrice);
        model.addAttribute("filterFood", alcohol);
        model.addAttribute("filterIndoor", light);


        return "venuelist";
    }

    private Boolean filterStringToBoolean(String filterString) {
        return (filterString == null || filterString.equals("all")) ? null : filterString.equals("yes");
    }
}
